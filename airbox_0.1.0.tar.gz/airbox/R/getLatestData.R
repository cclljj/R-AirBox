getLatestData <- function(Source = 2 , raw.data = FALSE)
{

  #Check for necessary packages
  if("RJSONIO" %in% rownames(installed.packages()) == FALSE)
  {
    install.packages('RJSONIO')
  }
  library(RJSONIO)

  if("jsonlite" %in% rownames(installed.packages()) == FALSE)
  {
    install.packages('jsonlite')
  }
  library(jsonlite)

  #Build a list to confirm whether there is mistake in source input
  source.list <- as.list(c('LASS' , 'Airbox' , 'MAPS' , 'ProbeCube' , 'Indie' , 'Webduino' , 'TW_EPA'))
  Source <- as.vector(Source)

  for(i in Source)
  {
    if(!(i %in% c(0:7)))
    {
      stop.word <- paste0('one or multiple source(s) in input Source does not include in our datasets , please read description of getLatestData')
      stop(stop.word)
    }
  }

  if(0 %in% Source)
  {
    Source <- source.list
  }else{
    Source <- source.list[Source]
  }



  url.LASS <- 'https://data.lass-net.org/data/last-all-lass.json'
  url.Airbox <- 'https://data.lass-net.org/data/last-all-airbox.json'
  url.MAPS <- 'https://data.lass-net.org/data/last-all-maps.json'
  url.ProbeCube <- 'https://data.lass-net.org/data/last-all-probecube.json'
  url.Indie <- 'https://data.lass-net.org/data/last-all-indie.json'
  url.Webduino <- 'https://data.lass-net.org/data/last-all-webduino.json'
  url.TW_EPA <- 'https://data.lass-net.org/data/last-all-epa.json'

  User <- as.list(Sys.info())
  username <- User$user

  if(Sys.info()['sysname'] == 'Darwin')
  {
    path <- as.character(paste0('/Users/' , username))
    method.download <- 'curl'
  }

  if(Sys.info()['sysname'] == 'Windows')
  {
    path <- as.character(paste0('C:/Users/' , username))
    method.download <- 'wb'
  }

  path.LASS <- paste0(path , '/LASS.json')
  path.Airbox <- paste0(path , '/Airbox.json')
  path.MAPS <- paste0(path , '/MAPS.json')
  path.ProbeCube <- paste0(path , '/ProbeCube.json')
  path.Indie <- paste0(path , '/Indie.json')
  path.Webduino <- paste0(path , '/Webduino.json')
  path.TW_EPA <- paste0(path , '/TW_EPA.json')

  if('LASS' %in% Source)
  {
    download.file(url.LASS , path.LASS , method = method.download)
    LASSJson <- fromJSON(path.LASS)
    if(is.data.frame(LASSJson$feeds) == T){
      LASS.5min.data <<- as.data.frame(LASSJson)

      if(raw.data == FALSE)
      {
        wanted <- c('feeds.date' , 'feeds.time' , 'feeds.device_id' , 'feeds.s_d0' ,
                    'feeds.s_d1' , 'feeds.s_d2' , 'feeds.s_t0' , 'feeds.s_h0' ,
                    'feeds.gps_lat' , 'feeds.gps_lon')
        LASS.5min.data.1 <- LASS.5min.data[ , wanted]
        name <- c('Date' , 'Time' , 'device_id' , 'PM2.5' , 'PM10' , 'PM1' , 'Temperature' ,
                  'Humidity' , 'lat' ,  'lon')
        colnames(LASS.5min.data.1) <- name
        LASS.5min.data.1$Time_1 <- paste0(LASS.5min.data.1$Date , ' ' , LASS.5min.data.1$Time)
        LASS.5min.data.1$Time_1 <- as.POSIXlt(LASS.5min.data.1$Time_1 , format = '%Y-%m-%d %H:%M:%S')
        LASS.5min.data <<- LASS.5min.data.1
      }}else{
        warning("There is no latest samples of LASS devices")
      }
  }

  if('Airbox' %in% Source)
  {
    download.file(url.Airbox , path.Airbox , method = method.download)
    AirboxJson <- fromJSON(path.Airbox)
    if(is.data.frame(AirboxJson$feeds) == T){
      Airbox.5min.data <<- as.data.frame(AirboxJson)

      if(raw.data == FALSE)
      {
        wanted <- c('feeds.date' , 'feeds.time' , 'feeds.device_id' , 'feeds.s_d0' ,
                    'feeds.s_d1' , 'feeds.s_d2' , 'feeds.s_t0' , 'feeds.s_h0' ,
                    'feeds.gps_lat' , 'feeds.gps_lon')
        Airbox.5min.data.1 <- Airbox.5min.data[ , wanted]
        name <- c('Date' , 'Time' , 'device_id' , 'PM2.5' , 'PM10' , 'PM1' , 'Temperature' ,
                  'Humidity' , 'lat' ,  'lon')
        colnames(Airbox.5min.data.1) <- name
        Airbox.5min.data.1$Time_1 <- paste0(Airbox.5min.data.1$Date , ' ' , Airbox.5min.data.1$Time)
        Airbox.5min.data.1$Time_1 <- as.POSIXlt(Airbox.5min.data.1$Time_1 , format = '%Y-%m-%d %H:%M:%S')
        Airbox.5min.data <<- Airbox.5min.data.1
      }}else{
        warning("There is no latest samples of Airbox devices")
      }
  }

  if('MAPS' %in% Source)
  {
    download.file(url.MAPS , path.MAPS , method = method.download)
    MAPSJson <- fromJSON(path.MAPS)
    if(is.data.frame(MAPSJson$feeds) == T){
      MAPS.5min.data <<- as.data.frame(MAPSJson)

      if(raw.data == FALSE)
      {
        wanted <- c('feeds.date' , 'feeds.time' , 'feeds.device_id' , 'feeds.s_d0' ,
                    'feeds.s_d1' , 'feeds.s_d2' , 'feeds.s_t4' , 'feeds.s_h4' ,
                    'feeds.gps_lat' , 'feeds.gps_lon')
        MAPS.5min.data.1 <- MAPS.5min.data[ , wanted]
        name <- c('Date' , 'Time' , 'device_id' , 'PM2.5' , 'PM10' , 'PM1' , 'Temperature' ,
                  'Humidity' , 'lat' ,  'lon')
        colnames(MAPS.5min.data.1) <- name
        MAPS.5min.data.1$Time_1 <- paste0(MAPS.5min.data.1$Date , ' ' , MAPS.5min.data.1$Time)
        MAPS.5min.data.1$Time_1 <- as.POSIXlt(MAPS.5min.data.1$Time_1 , format = '%Y-%m-%d %H:%M:%S')
        MAPS.5min.data <<- MAPS.5min.data.1
      }}else{
        warning("There is no latest samples of MAPS devices")
      }
  }

  if('ProbeCube' %in% Source)
  {
    download.file(url.ProbeCube , path.ProbeCube , method = method.download)
    ProbeCubeJson <- fromJSON(path.ProbeCube)
    if(is.data.frame(ProbeCubeJson$feeds) == T){
      ProbeCube.5min.data <<- as.data.frame(ProbeCubeJson)

      if(raw.data == FALSE)
      {
        wanted <- c('feeds.date' , 'feeds.time' , 'feeds.device_id' , 'feeds.PM25' , 'feeds.Temperature' ,
                    'feeds.Humidity' , 'feeds.gps_lat' , 'feeds.gps_lon')
        ProbeCube.5min.data.1 <- ProbeCube.5min.data[ , wanted]
        name <- c('Date' , 'Time' , 'device_id' , 'PM2.5' , 'Temperature' ,
                  'Humidity' , 'lat' ,  'lon')
        colnames(ProbeCube.5min.data.1) <- name
        ProbeCube.5min.data.1$Time_1 <- paste0(ProbeCube.5min.data.1$Date , ' ' , ProbeCube.5min.data.1$Time)
        ProbeCube.5min.data.1$Time_1 <- as.POSIXlt(ProbeCube.5min.data.1$Time_1 , format = '%Y-%m-%d %H:%M:%S')
        ProbeCube.5min.data <<- ProbeCube.5min.data.1
      }}else{
        warning("There is no latest samples of ProbeCube devices")
      }
  }

  if('Indie' %in% Source)
  {
    download.file(url.Indie , path.Indie , method = method.download)
    IndieJson <- fromJSON(path.Indie)
    if(is.data.frame(IndieJson$feeds) == T){
      Indie.5min.data <<- as.data.frame(IndieJson)

      if(raw.data == FALSE)
      {
        wanted <- c('feeds.date' , 'feeds.time' , 'feeds.device_id' , 'feeds.s_d0' ,
                    'feeds.s_d1' , 'feeds.s_d2' , 'feeds.s_t5' , 'feeds.s_h5' ,
                    'feeds.gps_lat' , 'feeds.gps_lon')
        Indie.5min.data.1 <- Indie.5min.data[ , wanted]
        name <- c('Date' , 'Time' , 'device_id' , 'PM2.5' , 'PM10' , 'PM1' , 'Temperature' ,
                  'Humidity' , 'lat' ,  'lon')
        colnames(Indie.5min.data.1) <- name
        Indie.5min.data.1$Time_1 <- paste0(Indie.5min.data.1$Date , ' ' , Indie.5min.data.1$Time)
        Indie.5min.data.1$Time_1 <- as.POSIXlt(Indie.5min.data.1$Time_1 , format = '%Y-%m-%d %H:%M:%S')
        Indie.5min.data <<- Indie.5min.data.1
      }}else{
        warning("There is no latest samples of Indie devices")
      }

  }

  if('Webduino' %in% Source)
  {
    download.file(url.Webduino , path.Webduino , method = method.download)
    WebduinoJson <- fromJSON(path.Webduino)
    if(is.data.frame(WebduinoJson$feeds) == T){
      Webduino.5min.data <<- as.data.frame(WebduinoJson)

      if(raw.data == FALSE)
      {
        wanted <- c('feeds.date' , 'feeds.time' , 'feeds.device_id' , 'feeds.s_d0' ,
                    'feeds.s_d1' , 'feeds.s_d2' , 'feeds.s_t5' , 'feeds.s_h5' ,
                    'feeds.gps_lat' , 'feeds.gps_lon')
        Webduino.5min.data.1 <- Webduino.5min.data[ , wanted]
        name <- c('Date' , 'Time' , 'device_id' , 'PM2.5' , 'PM10' , 'PM1' , 'Temperature' ,
                  'Humidity' , 'lat' ,  'lon')
        colnames(Webduino.5min.data.1) <- name
        Webduino.5min.data.1$Time_1 <- paste0(Webduino.5min.data.1$Date , ' ' , Webduino.5min.data.1$Time)
        Webduino.5min.data.1$Time_1 <- as.POSIXlt(Webduino.5min.data.1$Time_1 , format = '%Y-%m-%d %H:%M:%S')
        Webduino.5min.data <<- Webduino.5min.data.1
      }}else{
        warning("There is no latest samples of Webduino devices")
      }

  }

  if('TW_EPA' %in% Source)
  {
    download.file(url.TW_EPA , path.TW_EPA , method = method.download )
    TW_EPAJson <- fromJSON(path.TW_EPA)
    if(is.data.frame(TW_EPAJson$feeds) == T){
      TW_EPA.5min.data <<- as.data.frame(TW_EPAJson)

      if(raw.data == FALSE)
      {
        wanted <- c('feeds.date' , 'feeds.time' , 'feeds.device_id' , 'feeds.PM2_5' ,
                    'feeds.PM10' , 'feeds.gps_lat' , 'feeds.gps_lon')
        TW_EPA.5min.data.1 <- TW_EPA.5min.data[ , wanted]
        name <- c('Date' , 'Time' , 'device_id' , 'PM2.5' , 'PM10'  , 'lat' ,  'lon')
        colnames(TW_EPA.5min.data.1) <- name
        TW_EPA.5min.data.1$Time_1 <- paste0(TW_EPA.5min.data.1$Date , ' ' , TW_EPA.5min.data.1$Time)
        TW_EPA.5min.data.1$Time_1 <- as.POSIXlt(TW_EPA.5min.data.1$Time_1 , format = '%Y-%m-%d %H:%M:%S')
        TW_EPA.5min.data <<- TW_EPA.5min.data.1
      }}else{
        warning("There is no latest samples of TW-EPA stations")
      }
  }

}
